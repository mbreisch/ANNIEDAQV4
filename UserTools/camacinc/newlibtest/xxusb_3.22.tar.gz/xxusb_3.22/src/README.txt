libxxusb.c

This is the source file for the Linux XX_USB library for using the WIENER CC_USB or VM_USB under linux.  It contains general function for both the CC_USB and VM_USB as well specific functions for each unit.  Complete documentation is available in the Manual for the XX_USB.

To Compile:
- Simply typing "make" will compile and make the library file.
- Typing "make install" will copy the library made by "make" into the /usr/lib directory.



This Linux library was tested by and this file written by:
Tim Hoagland / Andreas Ruben
       of 
WIENER, Plein & Baus, Corp.

If you have any questions or problems with this library, please contact us at:
support@wiener-us.com 
